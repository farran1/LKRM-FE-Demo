
-- Create teams table
CREATE TABLE public.teams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  coach_id UUID REFERENCES auth.users NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create players table
CREATE TABLE public.players (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  name TEXT NOT NULL,
  jersey_number INTEGER NOT NULL,
  position TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(team_id, jersey_number)
);

-- Create games table
CREATE TABLE public.games (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  opponent_name TEXT NOT NULL,
  game_date TIMESTAMP WITH TIME ZONE NOT NULL,
  is_practice BOOLEAN NOT NULL DEFAULT false,
  game_clock_minutes INTEGER DEFAULT 32,
  quarter_length INTEGER DEFAULT 8,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'halftime', 'completed')),
  current_quarter INTEGER DEFAULT 1,
  current_clock_time INTEGER DEFAULT 0, -- seconds remaining in current quarter
  home_score INTEGER DEFAULT 0,
  away_score INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create stat_categories table for custom configuration
CREATE TABLE public.stat_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  category_type TEXT NOT NULL CHECK (category_type IN ('positive', 'negative', 'neutral')),
  points_value INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create game_stats table for individual stat entries
CREATE TABLE public.game_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  game_id UUID REFERENCES public.games NOT NULL,
  player_id UUID REFERENCES public.players NOT NULL,
  stat_category_id UUID REFERENCES public.stat_categories NOT NULL,
  quarter INTEGER NOT NULL,
  game_clock_time INTEGER, -- seconds remaining when stat occurred
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  notes TEXT
);

-- Create halftime_reports table
CREATE TABLE public.halftime_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  game_id UUID REFERENCES public.games NOT NULL,
  generated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  key_insights JSONB,
  recommended_adjustments JSONB,
  performance_metrics JSONB
);

-- Create team_settings table for workflow configuration
CREATE TABLE public.team_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  stat_entry_workflow TEXT DEFAULT 'player_first' CHECK (stat_entry_workflow IN ('player_first', 'action_first')),
  auto_clock_sync BOOLEAN DEFAULT true,
  default_view TEXT DEFAULT 'live_stats' CHECK (default_view IN ('live_stats', 'clock_view', 'player_view')),
  settings JSONB,
  UNIQUE(team_id)
);

-- Enable RLS on all tables
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stat_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.halftime_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for teams
CREATE POLICY "Users can view their own teams" ON public.teams FOR SELECT USING (auth.uid() = coach_id);
CREATE POLICY "Users can create their own teams" ON public.teams FOR INSERT WITH CHECK (auth.uid() = coach_id);
CREATE POLICY "Users can update their own teams" ON public.teams FOR UPDATE USING (auth.uid() = coach_id);
CREATE POLICY "Users can delete their own teams" ON public.teams FOR DELETE USING (auth.uid() = coach_id);

-- RLS Policies for players
CREATE POLICY "Users can view players from their teams" ON public.players FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create players for their teams" ON public.players FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update players from their teams" ON public.players FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can delete players from their teams" ON public.players FOR DELETE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- RLS Policies for games
CREATE POLICY "Users can view games from their teams" ON public.games FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create games for their teams" ON public.games FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update games from their teams" ON public.games FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can delete games from their teams" ON public.games FOR DELETE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- RLS Policies for stat_categories
CREATE POLICY "Users can view stat categories from their teams" ON public.stat_categories FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create stat categories for their teams" ON public.stat_categories FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update stat categories from their teams" ON public.stat_categories FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can delete stat categories from their teams" ON public.stat_categories FOR DELETE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- RLS Policies for game_stats
CREATE POLICY "Users can view game stats from their teams" ON public.game_stats FOR SELECT USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can create game stats for their teams" ON public.game_stats FOR INSERT WITH CHECK (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can update game stats from their teams" ON public.game_stats FOR UPDATE USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can delete game stats from their teams" ON public.game_stats FOR DELETE USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);

-- RLS Policies for halftime_reports
CREATE POLICY "Users can view halftime reports from their teams" ON public.halftime_reports FOR SELECT USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can create halftime reports for their teams" ON public.halftime_reports FOR INSERT WITH CHECK (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can update halftime reports from their teams" ON public.halftime_reports FOR UPDATE USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);

-- RLS Policies for team_settings
CREATE POLICY "Users can view settings for their teams" ON public.team_settings FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create settings for their teams" ON public.team_settings FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update settings for their teams" ON public.team_settings FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- Insert default stat categories
INSERT INTO public.stat_categories (team_id, name, display_name, category_type, points_value, sort_order) VALUES
-- This will be populated after team creation via the app
-- Common basketball stats that teams can customize
('00000000-0000-0000-0000-000000000000', 'field_goal_made', '2PT Made', 'positive', 2, 1),
('00000000-0000-0000-0000-000000000000', 'field_goal_missed', '2PT Missed', 'negative', 0, 2),
('00000000-0000-0000-0000-000000000000', 'three_point_made', '3PT Made', 'positive', 3, 3),
('00000000-0000-0000-0000-000000000000', 'three_point_missed', '3PT Missed', 'negative', 0, 4),
('00000000-0000-0000-0000-000000000000', 'free_throw_made', 'FT Made', 'positive', 1, 5),
('00000000-0000-0000-0000-000000000000', 'free_throw_missed', 'FT Missed', 'negative', 0, 6),
('00000000-0000-0000-0000-000000000000', 'rebound_offensive', 'Off. Rebound', 'positive', 0, 7),
('00000000-0000-0000-0000-000000000000', 'rebound_defensive', 'Def. Rebound', 'positive', 0, 8),
('00000000-0000-0000-0000-000000000000', 'assist', 'Assist', 'positive', 0, 9),
('00000000-0000-0000-0000-000000000000', 'steal', 'Steal', 'positive', 0, 10),
('00000000-0000-0000-0000-000000000000', 'block', 'Block', 'positive', 0, 11),
('00000000-0000-0000-0000-000000000000', 'turnover', 'Turnover', 'negative', 0, 12),
('00000000-0000-0000-0000-000000000000', 'foul_personal', 'Personal Foul', 'negative', 0, 13),
('00000000-0000-0000-0000-000000000000', 'foul_technical', 'Technical Foul', 'negative', 0, 14);
