
-- Create teams table
CREATE TABLE public.teams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  coach_id UUID REFERENCES auth.users NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create players table
CREATE TABLE public.players (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  name TEXT NOT NULL,
  jersey_number INTEGER NOT NULL,
  position TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(team_id, jersey_number)
);

-- Create games table
CREATE TABLE public.games (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  opponent_name TEXT NOT NULL,
  game_date TIMESTAMP WITH TIME ZONE NOT NULL,
  is_practice BOOLEAN NOT NULL DEFAULT false,
  game_clock_minutes INTEGER DEFAULT 32,
  quarter_length INTEGER DEFAULT 8,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'halftime', 'completed')),
  current_quarter INTEGER DEFAULT 1,
  current_clock_time INTEGER DEFAULT 0,
  home_score INTEGER DEFAULT 0,
  away_score INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create stat_categories table
CREATE TABLE public.stat_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_id UUID REFERENCES public.teams NOT NULL,
  name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  category_type TEXT NOT NULL CHECK (category_type IN ('positive', 'negative', 'neutral')),
  points_value INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create game_stats table
CREATE TABLE public.game_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  game_id UUID REFERENCES public.games NOT NULL,
  player_id UUID REFERENCES public.players NOT NULL,
  stat_category_id UUID REFERENCES public.stat_categories NOT NULL,
  quarter INTEGER NOT NULL,
  game_clock_time INTEGER,
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  notes TEXT
);

-- Enable RLS on all tables
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stat_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_stats ENABLE ROW LEVEL SECURITY;

-- RLS Policies for teams
CREATE POLICY "Users can view their own teams" ON public.teams FOR SELECT USING (auth.uid() = coach_id);
CREATE POLICY "Users can create their own teams" ON public.teams FOR INSERT WITH CHECK (auth.uid() = coach_id);
CREATE POLICY "Users can update their own teams" ON public.teams FOR UPDATE USING (auth.uid() = coach_id);
CREATE POLICY "Users can delete their own teams" ON public.teams FOR DELETE USING (auth.uid() = coach_id);

-- RLS Policies for players
CREATE POLICY "Users can view players from their teams" ON public.players FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create players for their teams" ON public.players FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update players from their teams" ON public.players FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can delete players from their teams" ON public.players FOR DELETE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- RLS Policies for games
CREATE POLICY "Users can view games from their teams" ON public.games FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create games for their teams" ON public.games FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update games from their teams" ON public.games FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can delete games from their teams" ON public.games FOR DELETE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- RLS Policies for stat_categories
CREATE POLICY "Users can view stat categories from their teams" ON public.stat_categories FOR SELECT USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can create stat categories for their teams" ON public.stat_categories FOR INSERT WITH CHECK (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can update stat categories from their teams" ON public.stat_categories FOR UPDATE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);
CREATE POLICY "Users can delete stat categories from their teams" ON public.stat_categories FOR DELETE USING (
  team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid())
);

-- RLS Policies for game_stats
CREATE POLICY "Users can view game stats from their teams" ON public.game_stats FOR SELECT USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can create game stats for their teams" ON public.game_stats FOR INSERT WITH CHECK (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can update game stats from their teams" ON public.game_stats FOR UPDATE USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
CREATE POLICY "Users can delete game stats from their teams" ON public.game_stats FOR DELETE USING (
  game_id IN (SELECT id FROM public.games WHERE team_id IN (SELECT id FROM public.teams WHERE coach_id = auth.uid()))
);
