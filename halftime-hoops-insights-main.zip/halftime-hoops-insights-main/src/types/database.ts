
// Database type definitions to work around missing Supabase types
export interface Team {
  id: string;
  name: string;
  coach_id: string;
  created_at: string;
}

export interface Player {
  id: string;
  team_id: string;
  name: string;
  jersey_number: number;
  position?: string;
  created_at: string;
}

export interface Game {
  id: string;
  team_id: string;
  opponent_name: string;
  game_date: string;
  is_practice: boolean;
  game_clock_minutes: number;
  quarter_length: number;
  status: 'scheduled' | 'in_progress' | 'halftime' | 'completed';
  current_quarter: number;
  current_clock_time: number;
  home_score: number;
  away_score: number;
  created_at: string;
}

export interface StatCategory {
  id: string;
  team_id: string;
  name: string;
  display_name: string;
  category_type: 'positive' | 'negative' | 'neutral';
  points_value: number;
  is_active: boolean;
  sort_order: number;
  created_at: string;
}

export interface GameStat {
  id: string;
  game_id: string;
  player_id: string;
  stat_category_id: string;
  quarter: number;
  game_clock_time?: number;
  timestamp: string;
  notes?: string;
  players?: {
    name: string;
    jersey_number: number;
  };
  stat_categories?: {
    display_name: string;
    points_value: number;
    name: string;
    category_type: string;
  };
}

export interface TeamWithGames extends Team {
  games?: Game[];
}

export interface GameWithTeam extends Game {
  teams?: {
    name: string;
    coach_id: string;
  };
}
