import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Users, User, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Team, Player } from '@/types/database';
import { AuthCard } from '@/components/auth/AuthCard';
import { useCreateDefaultStatCategories } from '@/components/team/DefaultStatCategories';

const TeamSetup = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const createDefaultStatCategories = useCreateDefaultStatCategories();
  
  const [teamName, setTeamName] = useState('');
  const [selectedTeam, setSelectedTeam] = useState<string>('');
  const [playerName, setPlayerName] = useState('');
  const [jerseyNumber, setJerseyNumber] = useState('');
  const [position, setPosition] = useState('');

  const { data: teams } = useQuery({
    queryKey: ['teams', user?.id],
    queryFn: async (): Promise<Team[]> => {
      if (!user) return [];
      const { data, error } = await (supabase as any)
        .from('teams')
        .select('*')
        .eq('coach_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  const { data: players } = useQuery({
    queryKey: ['players', selectedTeam],
    queryFn: async (): Promise<Player[]> => {
      if (!selectedTeam) return [];
      const { data, error } = await (supabase as any)
        .from('players')
        .select('*')
        .eq('team_id', selectedTeam)
        .order('jersey_number');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!selectedTeam
  });

  const createTeamMutation = useMutation({
    mutationFn: async (name: string): Promise<Team> => {
      if (!user) throw new Error('User not authenticated');
      const { data, error } = await (supabase as any)
        .from('teams')
        .insert({
          name,
          coach_id: user.id
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: async (data) => {
      // Create default stat categories for the new team
      try {
        await createDefaultStatCategories.mutateAsync(data.id);
      } catch (error) {
        console.error('Failed to create default stat categories:', error);
      }
      
      queryClient.invalidateQueries({ queryKey: ['teams'] });
      setTeamName('');
      setSelectedTeam(data.id);
      toast({
        title: "Team Created!",
        description: `${data.name} has been created with default stat categories.`,
      });
    }
  });

  const createPlayerMutation = useMutation({
    mutationFn: async (playerData: { name: string; jersey_number: number; position?: string; team_id: string }): Promise<Player> => {
      const { data, error } = await (supabase as any)
        .from('players')
        .insert(playerData)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['players'] });
      setPlayerName('');
      setJerseyNumber('');
      setPosition('');
      toast({
        title: "Player Added!",
        description: "Player has been added to the team successfully.",
      });
    }
  });

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamName.trim()) return;
    createTeamMutation.mutate(teamName.trim());
  };

  const handleCreatePlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim() || !jerseyNumber || !selectedTeam) return;
    
    createPlayerMutation.mutate({
      name: playerName.trim(),
      jersey_number: parseInt(jerseyNumber),
      position: position.trim() || undefined,
      team_id: selectedTeam
    });
  };

  if (!user) {
    return <AuthCard />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Team Setup</h1>
              <p className="text-gray-600">Create and manage your teams and players</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Create Team */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Create New Team
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateTeam} className="space-y-4">
                <div>
                  <Label htmlFor="teamName">Team Name</Label>
                  <Input
                    id="teamName"
                    value={teamName}
                    onChange={(e) => setTeamName(e.target.value)}
                    placeholder="Enter team name..."
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={createTeamMutation.isPending}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Team
                </Button>
              </form>

              {/* Teams List */}
              <div className="mt-6">
                <h3 className="font-semibold mb-3">Your Teams</h3>
                {teams && teams.length > 0 ? (
                  <div className="space-y-2">
                    {teams.map(team => (
                      <div 
                        key={team.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedTeam === team.id 
                            ? 'bg-orange-100 border-orange-300' 
                            : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                        }`}
                        onClick={() => setSelectedTeam(team.id)}
                      >
                        <div className="font-medium">{team.name}</div>
                        <div className="text-sm text-gray-500">
                          Created {new Date(team.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No teams created yet.</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Add Players */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Add Players
                {selectedTeam && (
                  <span className="text-sm text-gray-500 ml-2">
                    to {teams?.find(t => t.id === selectedTeam)?.name}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedTeam ? (
                <>
                  <form onSubmit={handleCreatePlayer} className="space-y-4">
                    <div>
                      <Label htmlFor="playerName">Player Name</Label>
                      <Input
                        id="playerName"
                        value={playerName}
                        onChange={(e) => setPlayerName(e.target.value)}
                        placeholder="Enter player name..."
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="jerseyNumber">Jersey #</Label>
                        <Input
                          id="jerseyNumber"
                          type="number"
                          value={jerseyNumber}
                          onChange={(e) => setJerseyNumber(e.target.value)}
                          placeholder="00"
                          min="0"
                          max="99"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="position">Position (Optional)</Label>
                        <Input
                          id="position"
                          value={position}
                          onChange={(e) => setPosition(e.target.value)}
                          placeholder="PG, SG, SF..."
                        />
                      </div>
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={createPlayerMutation.isPending}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Player
                    </Button>
                  </form>

                  {/* Players List */}
                  <div className="mt-6">
                    <h3 className="font-semibold mb-3">Team Roster</h3>
                    {players && players.length > 0 ? (
                      <div className="space-y-2">
                        {players.map(player => (
                          <div 
                            key={player.id}
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                                {player.jersey_number}
                              </div>
                              <div>
                                <div className="font-medium">{player.name}</div>
                                {player.position && (
                                  <div className="text-sm text-gray-500">{player.position}</div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No players added yet.</p>
                    )}
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <User className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Select a team first to add players</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        {teams && teams.length > 0 && (
          <div className="mt-8 text-center">
            <Button 
              onClick={() => navigate('/live-game')}
              size="lg"
              className="bg-green-500 hover:bg-green-600 text-white"
            >
              Start Live Game
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeamSetup;
