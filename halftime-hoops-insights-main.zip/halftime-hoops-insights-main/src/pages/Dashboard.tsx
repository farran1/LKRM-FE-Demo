
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, PlayCircle, Settings, BarChart3, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AuthCard } from '@/components/auth/AuthCard';
import { useAuth } from '@/hooks/useAuth';
import { Team, GameWithTeam } from '@/types/database';

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: teams, isLoading } = useQuery({
    queryKey: ['teams', user?.id],
    queryFn: async (): Promise<Team[]> => {
      if (!user) return [];
      const { data, error } = await (supabase as any)
        .from('teams')
        .select('*')
        .eq('coach_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  const { data: recentGames } = useQuery({
    queryKey: ['recent-games', user?.id],
    queryFn: async (): Promise<GameWithTeam[]> => {
      if (!user) return [];
      const { data, error } = await (supabase as any)
        .from('games')
        .select(`
          *,
          teams!inner(name, coach_id)
        `)
        .eq('teams.coach_id', user.id)
        .order('game_date', { ascending: false })
        .limit(5);
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  if (!user) {
    return <AuthCard />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">StatTracker Pro</h1>
          <p className="text-gray-600">Professional Basketball Analytics for Coaches</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Button 
            onClick={() => navigate('/live-game')}
            className="h-20 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-xl shadow-lg"
          >
            <div className="flex flex-col items-center gap-2">
              <PlayCircle className="w-6 h-6" />
              <span className="font-semibold">Start Live Game</span>
            </div>
          </Button>
          
          <Button 
            onClick={() => navigate('/team-setup')}
            variant="outline"
            className="h-20 border-2 border-orange-200 hover:border-orange-300 rounded-xl"
          >
            <div className="flex flex-col items-center gap-2">
              <Users className="w-6 h-6 text-orange-600" />
              <span className="font-semibold">Manage Teams</span>
            </div>
          </Button>
          
          <Button 
            onClick={() => navigate('/analytics')}
            variant="outline"
            className="h-20 border-2 border-blue-200 hover:border-blue-300 rounded-xl"
          >
            <div className="flex flex-col items-center gap-2">
              <BarChart3 className="w-6 h-6 text-blue-600" />
              <span className="font-semibold">Analytics</span>
            </div>
          </Button>
          
          <Button 
            onClick={() => navigate('/settings')}
            variant="outline"
            className="h-20 border-2 border-gray-200 hover:border-gray-300 rounded-xl"
          >
            <div className="flex flex-col items-center gap-2">
              <Settings className="w-6 h-6 text-gray-600" />
              <span className="font-semibold">Settings</span>
            </div>
          </Button>
        </div>

        {/* Teams and Recent Games */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Teams */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Your Teams
                <Button 
                  onClick={() => navigate('/team-setup')}
                  size="sm"
                  className="bg-orange-500 hover:bg-orange-600"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Team
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="h-16 bg-gray-100 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : teams && teams.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No teams yet. Create your first team to get started!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {teams?.map(team => (
                    <div 
                      key={team.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                      onClick={() => navigate(`/team/${team.id}`)}
                    >
                      <div>
                        <h3 className="font-semibold text-gray-900">{team.name}</h3>
                        <p className="text-sm text-gray-500">Created {new Date(team.created_at).toLocaleDateString()}</p>
                      </div>
                      <Button size="sm" variant="ghost">
                        View →
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Games */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Recent Games</CardTitle>
            </CardHeader>
            <CardContent>
              {recentGames && recentGames.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <PlayCircle className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No games yet. Start tracking your first game!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentGames?.map(game => (
                    <div 
                      key={game.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                      onClick={() => navigate(`/game/${game.id}`)}
                    >
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          vs {game.opponent_name}
                        </h3>
                        <p className="text-sm text-gray-500">
                          {new Date(game.game_date).toLocaleDateString()} • 
                          <span className={`ml-1 px-2 py-1 rounded text-xs ${
                            game.status === 'completed' ? 'bg-green-100 text-green-700' :
                            game.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                            game.status === 'halftime' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-gray-100 text-gray-600'
                          }`}>
                            {game.status.replace('_', ' ').toUpperCase()}
                          </span>
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg">
                          {game.home_score} - {game.away_score}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
