
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, RotateCcw, Clock, Trophy, Users } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { GameClock } from '@/components/game/GameClock';
import { StatTracker } from '@/components/game/StatTracker';
import { PlayerGrid } from '@/components/game/PlayerGrid';
import { HalftimeReport } from '@/components/game/HalftimeReport';
import { Team, Game } from '@/types/database';

const LiveGame = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTeam, setSelectedTeam] = useState<string>('');
  const [currentGame, setCurrentGame] = useState<Game | null>(null);
  const [showHalftimeReport, setShowHalftimeReport] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<string>('');

  const { data: teams } = useQuery({
    queryKey: ['teams', user?.id],
    queryFn: async (): Promise<Team[]> => {
      if (!user) return [];
      const { data, error } = await (supabase as any)
        .from('teams')
        .select('*')
        .eq('coach_id', user.id);
      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  const { data: activeGame } = useQuery({
    queryKey: ['active-game', selectedTeam],
    queryFn: async (): Promise<Game | null> => {
      if (!selectedTeam) return null;
      const { data, error } = await (supabase as any)
        .from('games')
        .select('*')
        .eq('team_id', selectedTeam)
        .in('status', ['in_progress', 'halftime'])
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!selectedTeam
  });

  const startGameMutation = useMutation({
    mutationFn: async (gameData: any): Promise<Game> => {
      const { data, error } = await (supabase as any)
        .from('games')
        .insert(gameData)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      setCurrentGame(data);
      queryClient.invalidateQueries({ queryKey: ['active-game'] });
      toast({
        title: "Game Started!",
        description: "Live tracking is now active.",
      });
    }
  });

  const updateGameMutation = useMutation({
    mutationFn: async ({ gameId, updates }: { gameId: string; updates: any }): Promise<Game> => {
      const { data, error } = await (supabase as any)
        .from('games')
        .update(updates)
        .eq('id', gameId)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-game'] });
    }
  });

  useEffect(() => {
    if (activeGame) {
      setCurrentGame(activeGame);
      if (activeGame.status === 'halftime') {
        setShowHalftimeReport(true);
      }
    }
  }, [activeGame]);

  const startNewGame = () => {
    if (!selectedTeam) return;
    
    const opponent = prompt("Enter opponent name:");
    if (!opponent) return;

    startGameMutation.mutate({
      team_id: selectedTeam,
      opponent_name: opponent,
      game_date: new Date().toISOString(),
      status: 'in_progress',
      current_quarter: 1,
      current_clock_time: 8 * 60, // 8 minutes in seconds
    });
  };

  const handleGameStatusChange = (status: string) => {
    if (!currentGame) return;
    
    updateGameMutation.mutate({
      gameId: currentGame.id,
      updates: { status }
    });

    if (status === 'halftime') {
      setShowHalftimeReport(true);
    } else if (status === 'in_progress') {
      setShowHalftimeReport(false);
    }
  };

  if (!teams || teams.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-2 flex items-center justify-center">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle>No Teams Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">You need to create a team first before starting a game.</p>
            <Button onClick={() => window.location.href = '/team-setup'}>
              Create Team
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!selectedTeam) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-2">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold text-center mb-4">Select Your Team</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {teams.map(team => (
              <Card 
                key={team.id} 
                className="cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => setSelectedTeam(team.id)}
              >
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4" />
                    {team.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <Button size="sm" className="w-full">Select Team</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-2 overflow-hidden">
      <div className="h-screen flex flex-col max-w-7xl mx-auto">
        {/* Compact Header */}
        <div className="flex items-center justify-between mb-2 bg-white/80 backdrop-blur rounded-lg p-2">
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold text-gray-900 truncate">
              {teams?.find(t => t.id === selectedTeam)?.name}
              {currentGame && ` vs ${currentGame.opponent_name}`}
            </h1>
          </div>
          
          {!currentGame ? (
            <Button 
              onClick={startNewGame}
              className="bg-green-500 hover:bg-green-600 text-white ml-2"
              size="sm"
            >
              <Play className="w-3 h-3 mr-1" />
              Start
            </Button>
          ) : (
            <div className="flex gap-1 ml-2">
              <Badge variant={
                currentGame.status === 'in_progress' ? 'default' :
                currentGame.status === 'halftime' ? 'secondary' : 'outline'
              } className="text-xs">
                {currentGame.status.replace('_', ' ').toUpperCase()}
              </Badge>
              
              {currentGame.status === 'in_progress' && (
                <Button 
                  onClick={() => handleGameStatusChange('halftime')}
                  variant="outline"
                  size="sm"
                  className="text-xs px-2 py-1 h-6"
                >
                  Halftime
                </Button>
              )}
              
              {currentGame.status === 'halftime' && (
                <Button 
                  onClick={() => handleGameStatusChange('in_progress')}
                  variant="outline"
                  size="sm"
                  className="text-xs px-2 py-1 h-6"
                >
                  Resume
                </Button>
              )}
            </div>
          )}
        </div>

        {currentGame && (
          <>
            {/* Compact Game Info Bar */}
            <div className="grid grid-cols-3 gap-2 mb-2">
              <Card className="p-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-900">
                    {Math.floor((currentGame.current_clock_time || 0) / 60)}:{((currentGame.current_clock_time || 0) % 60).toString().padStart(2, '0')}
                  </div>
                  <div className="text-xs text-gray-500">Clock</div>
                </div>
              </Card>
              
              <Card className="p-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-900">
                    {currentGame.home_score} - {currentGame.away_score}
                  </div>
                  <div className="text-xs text-gray-500">Score</div>
                </div>
              </Card>
              
              <Card className="p-2">
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-900">
                    Q{currentGame.current_quarter}
                  </div>
                  <div className="text-xs text-gray-500">Quarter</div>
                </div>
              </Card>
            </div>

            {/* Halftime Report Modal */}
            {showHalftimeReport && (
              <HalftimeReport 
                gameId={currentGame.id}
                onClose={() => setShowHalftimeReport(false)}
              />
            )}

            {/* Main Game Interface - Responsive Layout */}
            <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-3 gap-2">
              {/* Player Selection */}
              <div className="lg:col-span-1">
                <PlayerGrid 
                  teamId={selectedTeam} 
                  gameId={currentGame.id}
                  selectedPlayer={selectedPlayer}
                  onPlayerSelect={setSelectedPlayer}
                />
              </div>
              
              {/* Stat Tracker */}
              <div className="lg:col-span-2">
                <StatTracker 
                  teamId={selectedTeam}
                  gameId={currentGame.id}
                  selectedPlayer={selectedPlayer}
                />
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default LiveGame;
