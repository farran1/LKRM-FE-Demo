
import { useMutation } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { StatCategory } from '@/types/database';

const defaultStatCategories = [
  { name: 'field_goal_made', display_name: '2PT Made', category_type: 'positive', points_value: 2, sort_order: 1 },
  { name: 'field_goal_missed', display_name: '2PT Missed', category_type: 'negative', points_value: 0, sort_order: 2 },
  { name: 'three_point_made', display_name: '3PT Made', category_type: 'positive', points_value: 3, sort_order: 3 },
  { name: 'three_point_missed', display_name: '3PT Missed', category_type: 'negative', points_value: 0, sort_order: 4 },
  { name: 'free_throw_made', display_name: 'FT Made', category_type: 'positive', points_value: 1, sort_order: 5 },
  { name: 'free_throw_missed', display_name: 'FT Missed', category_type: 'negative', points_value: 0, sort_order: 6 },
  { name: 'rebound_offensive', display_name: 'Off. Rebound', category_type: 'positive', points_value: 0, sort_order: 7 },
  { name: 'rebound_defensive', display_name: 'Def. Rebound', category_type: 'positive', points_value: 0, sort_order: 8 },
  { name: 'assist', display_name: 'Assist', category_type: 'positive', points_value: 0, sort_order: 9 },
  { name: 'steal', display_name: 'Steal', category_type: 'positive', points_value: 0, sort_order: 10 },
  { name: 'block', display_name: 'Block', category_type: 'positive', points_value: 0, sort_order: 11 },
  { name: 'turnover', display_name: 'Turnover', category_type: 'negative', points_value: 0, sort_order: 12 },
  { name: 'foul_personal', display_name: 'Personal Foul', category_type: 'negative', points_value: 0, sort_order: 13 },
];

export const useCreateDefaultStatCategories = () => {
  return useMutation({
    mutationFn: async (teamId: string): Promise<StatCategory[]> => {
      const statCategoriesToInsert = defaultStatCategories.map(stat => ({
        ...stat,
        team_id: teamId,
        category_type: stat.category_type as 'positive' | 'negative' | 'neutral',
      }));

      const { data, error } = await (supabase as any)
        .from('stat_categories')
        .insert(statCategoriesToInsert)
        .select();
      
      if (error) throw error;
      return data || [];
    },
  });
};
