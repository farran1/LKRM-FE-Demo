
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Player, GameStat } from '@/types/database';

interface PlayerGridProps {
  teamId: string;
  gameId: string;
  selectedPlayer: string;
  onPlayerSelect: (playerId: string) => void;
}

export const PlayerGrid: React.FC<PlayerGridProps> = ({ 
  teamId, 
  gameId, 
  selectedPlayer, 
  onPlayerSelect 
}) => {
  const { data: players } = useQuery({
    queryKey: ['team-players', teamId],
    queryFn: async (): Promise<Player[]> => {
      const { data, error } = await (supabase as any)
        .from('players')
        .select('*')
        .eq('team_id', teamId)
        .order('jersey_number');
      if (error) throw error;
      return data || [];
    },
    enabled: !!teamId
  });

  const { data: gameStats } = useQuery({
    queryKey: ['game-stats', gameId],
    queryFn: async (): Promise<GameStat[]> => {
      const { data, error } = await (supabase as any)
        .from('game_stats')
        .select(`
          *,
          players(name, jersey_number),
          stat_categories(display_name, points_value)
        `)
        .eq('game_id', gameId);
      if (error) throw error;
      return data || [];
    },
    enabled: !!gameId
  });

  const getPlayerStats = (playerId: string) => {
    if (!gameStats) return { points: 0, stats: 0 };
    
    const playerStats = gameStats.filter(stat => stat.player_id === playerId);
    const points = playerStats.reduce((sum, stat) => sum + (stat.stat_categories?.points_value || 0), 0);
    
    return { points, stats: playerStats.length };
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">Players</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-auto">
        <div className="grid grid-cols-2 gap-1">
          {players && players.length > 0 ? players.map(player => {
            const stats = getPlayerStats(player.id);
            const isSelected = selectedPlayer === player.id;
            
            return (
              <Button
                key={player.id}
                variant={isSelected ? "default" : "outline"}
                className={`h-12 flex flex-col justify-center text-xs p-1 ${
                  isSelected ? 'bg-orange-500 hover:bg-orange-600 text-white' : ''
                }`}
                onClick={() => onPlayerSelect(isSelected ? '' : player.id)}
              >
                <div className="font-bold text-sm">#{player.jersey_number}</div>
                <div className="text-xs truncate max-w-full">{player.name}</div>
                <div className="text-xs flex gap-1 mt-1">
                  <Badge variant="secondary" className="text-xs px-1 py-0 text-[10px]">
                    {stats.points}pts
                  </Badge>
                  <Badge variant="outline" className="text-xs px-1 py-0 text-[10px]">
                    {stats.stats}
                  </Badge>
                </div>
              </Button>
            );
          }) : (
            <div className="col-span-2 text-center text-gray-500 py-4 text-sm">
              No players found. Add players to your team first.
            </div>
          )}
        </div>
        
        {selectedPlayer && players && (
          <div className="mt-2 p-2 bg-orange-50 rounded-lg">
            <div className="text-center">
              <div className="font-semibold text-orange-800 text-sm">
                {players.find(p => p.id === selectedPlayer)?.name} Selected
              </div>
              <div className="text-xs text-orange-600">
                Tap a stat to record
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
