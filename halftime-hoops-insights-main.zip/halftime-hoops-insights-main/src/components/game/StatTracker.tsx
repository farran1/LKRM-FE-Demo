
import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { StatCategory, Game } from '@/types/database';

interface StatTrackerProps {
  teamId: string;
  gameId: string;
  selectedPlayer: string;
}

export const StatTracker: React.FC<StatTrackerProps> = ({ teamId, gameId, selectedPlayer }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: statCategories } = useQuery({
    queryKey: ['stat-categories', teamId],
    queryFn: async (): Promise<StatCategory[]> => {
      const { data, error } = await (supabase as any)
        .from('stat_categories')
        .select('*')
        .eq('team_id', teamId)
        .eq('is_active', true)
        .order('sort_order');
      if (error) throw error;
      return data || [];
    },
    enabled: !!teamId
  });

  const { data: gameData } = useQuery({
    queryKey: ['game-data', gameId],
    queryFn: async (): Promise<Game | null> => {
      const { data, error } = await (supabase as any)
        .from('games')
        .select('*')
        .eq('id', gameId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!gameId
  });

  const addStatMutation = useMutation({
    mutationFn: async ({ playerId, statCategoryId }: { playerId: string; statCategoryId: string }) => {
      console.log('Recording stat:', { playerId, statCategoryId, gameId });
      const { data, error } = await (supabase as any)
        .from('game_stats')
        .insert({
          game_id: gameId,
          player_id: playerId,
          stat_category_id: statCategoryId,
          quarter: gameData?.current_quarter || 1,
          game_clock_time: gameData?.current_clock_time || 0,
        });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['game-stats'] });
      toast({
        title: "Stat Recorded",
        description: "Successfully recorded the stat.",
      });
    },
    onError: (error) => {
      console.error('Error recording stat:', error);
      toast({
        title: "Error",
        description: "Failed to record stat. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleStatClick = (statCategoryId: string) => {
    if (!selectedPlayer) {
      toast({
        title: "Select a Player",
        description: "Please select a player first before recording stats.",
        variant: "destructive"
      });
      return;
    }

    addStatMutation.mutate({ 
      playerId: selectedPlayer, 
      statCategoryId 
    });
  };

  const getStatColor = (categoryType: string) => {
    switch (categoryType) {
      case 'positive': return 'bg-green-500 hover:bg-green-600 text-white';
      case 'negative': return 'bg-red-500 hover:bg-red-600 text-white';
      default: return 'bg-gray-500 hover:bg-gray-600 text-white';
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">Record Stats</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-auto">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-1">
          {statCategories && statCategories.length > 0 ? statCategories.map(category => (
            <Button
              key={category.id}
              className={`h-12 flex flex-col justify-center text-xs p-1 ${getStatColor(category.category_type)}`}
              onClick={() => handleStatClick(category.id)}
              disabled={addStatMutation.isPending}
            >
              <div className="font-semibold text-xs leading-tight">{category.display_name}</div>
              {(category.points_value || 0) > 0 && (
                <Badge variant="secondary" className="mt-1 text-[10px] px-1 py-0">
                  +{category.points_value}
                </Badge>
              )}
            </Button>
          )) : (
            <div className="col-span-full text-center text-gray-500 py-4 text-sm">
              No stat categories configured. Set up your team's stats first.
            </div>
          )}
        </div>
        
        <div className="mt-4 p-2 bg-gray-50 rounded-lg">
          <h3 className="font-semibold mb-1 text-sm">Quick Tips:</h3>
          <ul className="text-xs text-gray-600 space-y-1">
            <li>• Select a player first, then tap the stat</li>
            <li>• Green buttons add points, red buttons track mistakes</li>
            <li>• Stats are automatically timestamped</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};
