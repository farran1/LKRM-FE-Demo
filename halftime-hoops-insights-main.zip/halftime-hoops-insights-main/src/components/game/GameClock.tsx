
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw } from 'lucide-react';

interface GameClockProps {
  game: any;
  onUpdate: (updates: any) => void;
}

export const GameClock: React.FC<GameClockProps> = ({ game, onUpdate }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(game.current_clock_time);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          const newTime = prev - 1;
          if (newTime <= 0) {
            setIsRunning(false);
            // Auto advance quarter logic could go here
          }
          return Math.max(0, newTime);
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isRunning, timeRemaining]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const toggleClock = () => {
    setIsRunning(!isRunning);
  };

  const resetQuarter = () => {
    const quarterLength = game.quarter_length * 60; // Convert to seconds
    setTimeRemaining(quarterLength);
    setIsRunning(false);
    onUpdate({ current_clock_time: quarterLength });
  };

  const saveTime = () => {
    onUpdate({ current_clock_time: timeRemaining });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-center">Game Clock</CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <div className="text-6xl font-mono font-bold text-gray-900">
          {formatTime(timeRemaining)}
        </div>
        
        <div className="flex justify-center gap-2">
          <Button 
            onClick={toggleClock}
            variant={isRunning ? "destructive" : "default"}
            size="sm"
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          
          <Button 
            onClick={resetQuarter}
            variant="outline"
            size="sm"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
        
        <Button 
          onClick={saveTime}
          size="sm"
          variant="outline"
          className="w-full"
        >
          Save Time
        </Button>
      </CardContent>
    </Card>
  );
};
