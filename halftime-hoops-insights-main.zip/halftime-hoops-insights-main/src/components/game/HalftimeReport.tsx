
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { TrendingUp, TrendingDown, Target, Trophy } from 'lucide-react';
import { GameStat, Game } from '@/types/database';

interface HalftimeReportProps {
  gameId: string;
  onClose: () => void;
}

export const HalftimeReport: React.FC<HalftimeReportProps> = ({ gameId, onClose }) => {
  const { data: gameStats } = useQuery({
    queryKey: ['halftime-stats', gameId],
    queryFn: async (): Promise<GameStat[]> => {
      const { data, error } = await (supabase as any)
        .from('game_stats')
        .select(`
          *,
          players(name, jersey_number),
          stat_categories(display_name, category_type, points_value, name)
        `)
        .eq('game_id', gameId)
        .lte('quarter', 2); // First half only
      if (error) throw error;
      return data || [];
    },
    enabled: !!gameId
  });

  const { data: gameData } = useQuery({
    queryKey: ['game-data', gameId],
    queryFn: async (): Promise<Game | null> => {
      const { data, error } = await (supabase as any)
        .from('games')
        .select('*')
        .eq('id', gameId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!gameId
  });

  const generateInsights = () => {
    if (!gameStats || gameStats.length === 0) return [];

    const insights = [];
    
    // Top performers
    const playerStats = gameStats.reduce((acc: any, stat) => {
      const playerId = stat.player_id;
      if (!acc[playerId]) {
        acc[playerId] = {
          name: stat.players?.name || 'Unknown Player',
          jersey: stat.players?.jersey_number || 0,
          points: 0,
          positive: 0,
          negative: 0
        };
      }
      acc[playerId].points += stat.stat_categories?.points_value || 0;
      if (stat.stat_categories?.category_type === 'positive') acc[playerId].positive++;
      if (stat.stat_categories?.category_type === 'negative') acc[playerId].negative++;
      return acc;
    }, {});

    const topScorer = Object.values(playerStats).sort((a: any, b: any) => b.points - a.points)[0] as any;
    if (topScorer && topScorer.points > 0) {
      insights.push({
        type: 'positive',
        title: 'Top Performer',
        description: `#${topScorer.jersey} ${topScorer.name} leads with ${topScorer.points} points`,
        icon: Trophy
      });
    }

    // Shooting analysis
    const fieldGoals = gameStats.filter(s => s.stat_categories?.name?.includes('field_goal'));
    const made = fieldGoals.filter(s => s.stat_categories?.name?.includes('made')).length;
    const attempted = fieldGoals.length;
    const percentage = attempted > 0 ? Math.round((made / attempted) * 100) : 0;

    if (attempted > 0) {
      insights.push({
        type: percentage >= 45 ? 'positive' : 'negative',
        title: 'Field Goal %',
        description: `${percentage}% shooting (${made}/${attempted})`,
        icon: Target
      });
    }

    // Turnovers
    const turnovers = gameStats.filter(s => s.stat_categories?.name === 'turnover').length;
    if (turnovers > 0) {
      insights.push({
        type: turnovers <= 8 ? 'positive' : 'negative',
        title: 'Ball Security',
        description: `${turnovers} turnovers in first half`,
        icon: TrendingDown
      });
    }

    return insights;
  };

  const generateAdjustments = () => {
    const adjustments = [
      "Focus on ball movement - look for extra pass opportunities",
      "Increase defensive pressure on opponent's leading scorer",
      "Attack the paint more - draw fouls and get easier shots",
      "Communicate better on defensive switches",
      "Push tempo in transition after defensive rebounds"
    ];
    
    return adjustments.slice(0, 3); // Show top 3 suggestions
  };

  const insights = generateInsights();
  const adjustments = generateAdjustments();

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-center">
            Halftime Report
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Key Insights */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Key Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {insights.length > 0 ? insights.map((insight, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-gray-50">
                  <div className={`p-2 rounded-full ${
                    insight.type === 'positive' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    <insight.icon className={`w-4 h-4 ${
                      insight.type === 'positive' ? 'text-green-600' : 'text-red-600'
                    }`} />
                  </div>
                  <div>
                    <div className="font-semibold">{insight.title}</div>
                    <div className="text-sm text-gray-600">{insight.description}</div>
                  </div>
                </div>
              )) : (
                <div className="text-center text-gray-500 py-4">
                  No stats recorded yet for the first half.
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recommended Adjustments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Recommended Adjustments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {adjustments.map((adjustment, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-blue-50">
                  <Badge variant="outline" className="mt-0.5">
                    {index + 1}
                  </Badge>
                  <div className="text-sm">{adjustment}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Score Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-center">First Half Summary</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {gameData?.home_score || 0} - {gameData?.away_score || 0}
            </div>
            <div className="text-gray-600">
              Total Stats Recorded: {gameStats?.length || 0}
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center">
          <Button 
            onClick={onClose}
            className="bg-orange-500 hover:bg-orange-600 text-white"
          >
            Continue to Second Half
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
